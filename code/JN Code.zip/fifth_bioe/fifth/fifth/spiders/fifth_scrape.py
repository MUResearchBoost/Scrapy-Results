import scrapy
from fifth.items import FifthItem
from datetime import datetime
import re


class Fifth(scrapy.Spider):
    name = "sios"
    
    # First Start Url
    start_urls = ["http://bioengineering.missouri.edu/faculty/"]
    
    
    global lines
    lines=[2,4,6]
    def parse(self, response):
        for i in range(1, 4):
            check = 0
            for o in range (1, 50):
                if check == 1:
                    break
                for s in lines:
                    href = "".join(response.xpath('//*[@id="primaryContent"]/table['+str(i)+']//tr['+str(o)+']/td['+str(s)+']/a/@href').extract())
                    print(href)
                    if len(href) < 1:
                        check=1 
                        break
                    url=href
                    
                    callback=self.parse_dir_contents
                    yield scrapy.Request(url, callback)
                
    
    def parse_dir_contents(self, response):
        item = FifthItem()
        sb=0
        #name
        na = "".join(response.xpath('//*[@id="primaryContent"]/h2[1]/descendant::text()').extract()).strip()
        if len(na) < 1:# for all special cases, there is only name will be scraped. Check the pages for the rest info.
            na = "".join(response.xpath('//div[@class="person-info"]/h2/descendant::text()').extract()).strip()
            sb=1
        item['name'] = na
        
        #identity. if sequence here is vital
        id = "".join(response.xpath('//*[@id="primaryContent"]/b').extract()).strip()
        if len(id) < 1:
            id = "".join(response.xpath('//*[@id="primaryContent"]/strong/descendant::text()').extract()).strip()
        if len(id) < 1:
            id = "".join(response.xpath('//*[@id="primaryContent"]/p/descendant::text()').extract()).strip()
        #three different site for one staff!!
        if len(id) < 1: #This is a arbitrary page which does not follow the general form. lazy creator.
            id ="Warning: No /p /strong /b."
        id = re.sub('<[^<]+?>', ' ', id)
        id= ' '.join(id.split())
        if sb==1:
            id = "This is an unique page. You may check the page directly."
        item['identity'] = id
        
        #personal info.
        pi="".join(response.xpath('//*[@id="primaryContent"]/ul[@class="text-90"]/descendant::text()').extract()).strip()
        if sb==1:
            pi = "This is an unique page. You may check the page directly."
        item['personal_info'] = pi
        
        #education
        ed = "".join(response.xpath('//*[@id="primaryContent"]/h2[2]/following-sibling::ul[count(preceding-sibling::h2) < 3]').extract()).strip()
        if len(ed) < 1:
            ed = "This field does not exist. Or check the page!"
        ed = re.sub('<[^<]+?>', '\n', ed)
        ed = re.sub(' ', '', ed)
        ed = re.sub('\n', ' ', ed)
        if sb==1:
            ed = "This is an unique page. You may check the page directly."
        item['education'] = ed
        
        #research
        res = "".join(response.xpath('//*[@id="primaryContent"]/h2[3]/following-sibling::ul[count(preceding-sibling::h2) < 4]').extract()).strip()
        if len(res) < 1:
            res = "".join(response.xpath('//*[@id="primaryContent"]/h2[3]/following-sibling::p[count(preceding-sibling::h2) < 4]').extract()).strip()
        if len(res) < 1:
            res = "This field does not exist. Or check the page!"
        res = re.sub('<[^<]+?>', ' ', res)
        res=' '.join(res.split())
        if sb==1:
            res = "This is an unique page. You may check the page directly."
        item['research'] = res
        
        #url
        a= "".join(response.xpath('//*[@id="primaryContent"]/img').extract()).strip()
            #'http://bioengineering.missouri.edu/images/faculty/borgelt-s.jpg'
        z="ty/"
        y=".jpg"
        b = a[a.find(z)+3 : a.find(y)]
        p_url = "http://bioengineering.missouri.edu/faculty/"+b+".php"
        
        if len(b)<1:
            p_url= "".join(response.xpath('/html/head/meta[12]/@content').extract()).strip()
        if len(p_url)<1:
            p_url = "There is something wrong. Check this on http://bioengineering.missouri.edu/faculty/ "
        
        item['url'] = p_url
        
        yield item
        
        