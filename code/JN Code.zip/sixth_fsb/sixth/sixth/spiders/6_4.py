import scrapy
from sixth.items import SixthItem
from datetime import datetime
import re


class Sixth(scrapy.Spider):
    name = "sios4"
    #dont_filter=True
    # First Start Url
    start_urls = [
    "https://education.missouri.edu/people/faculty/",#gj
    #"https://healthprofessions.missouri.edu/faculty-staff/directory/",#gj
    #"http://nep.missouri.edu/faculty.html",#gj
    #"https://medicine.missouri.edu/faculty",#seems ok
    ]
    
    
    def parse(self, response):
        for i in range(1, 128):
            href = "".join(response.xpath('/html/body/main/div/div/section/div/div[2]/div['+str(i)+']/div/a/@href').extract())
            if len(href) < 1:
                
                break
                url=href
                callback=self.parse_dir_contents
                yield scrapy.Request(url, callback)
                        
    
    def parse_dir_contents(self, response):
        item = SixthItem()
        
        
        #name
        na = "".join(response.xpath('/html/body/main/div/div/div/article/div[2]/header/h1/descendant::text()').extract()).strip()
        
        if len(na)<1:
            na = "Name field may not exist."
        item['name'] = na
        
        #identity. if sequence here is vital
        id = "".join(response.xpath('//html/body/main/div/div/div/article/div[2]/header/ul[1]').extract()).strip()
        
        if len(id) < 1: #This is a arbitrary page which does not follow the general form. lazy creator.
            id ="identity field does not exist."
        item['identity'] = id
        
        #personal info.
        pi="".join(response.xpath('/html/body/main/div/div/div/article/div[1]/div/ul/descendant::text()').extract()).strip()
        
        if len(pi)<1:
            pi="This field may not exist. Check with the url."
        item['personal_info'] = pi
        
        #education
        ed = "".join(response.xpath('/html/body/main/div/div/div/article/div[2]/div[3]/descendant::text()').extract()).strip()
        
        if len(ed) < 1:
            ed = "Education field does not exist. Or check the page!"
        item['education'] = ed
        
        #research
        res = "".join(response.xpath('/html/body/main/div/div/div/article/div[2]/div[2]/descendant::text()').extract()).strip()
        
        if len(res) < 1:
            res = "This field does not exist. Or check the page!"
       
        item['research'] = res
        
        #url
        urlss=response.request.url
        if len(urlss)<1 or "." not in urlss:
            urlss="NULL"
        item['url']=urlss
        
      
        yield item
        
        