import scrapy
from sixth.items import SixthItem
from datetime import datetime
import re


class Sixth(scrapy.Spider):
    name = "sios5"
    #dont_filter=True
    # First Start Url
    
    start_urls = [
    "https://healthprofessions.missouri.edu/faculty-staff/directory/"#gj
    #"http://nep.missouri.edu/faculty.html",#gj
    #"https://medicine.missouri.edu/faculty",#seems ok
    ]
    for i in range(2,26):
        start_urls.append("https://healthprofessions.missouri.edu/faculty-staff/directory/page/"+str(i)+"/")
    
    def parse(self, response):
        for i in range(1, 9):
            href = "".join(response.xpath('/html/body/main/section/div/div/ul/li['+str(i)+']/div/div/div[2]/a[1]/@href').extract())
            if len(href) < 1:
                
                break
                url=href
                callback=self.parse_dir_contents
                yield scrapy.Request(url, callback)
                        
    
    def parse_dir_contents(self, response):
        item = SixthItem()
        
        
        #name
        na = "".join(response.xpath('/html/body/main/section/div/article/div[2]/div/h2/descendant::text()').extract()).strip()
        
        if len(na)<1:
            na = "Name field may not exist."
        item['name'] = na
        
        #identity. if sequence here is vital
        id = "".join(response.xpath('/html/body/main/section/div/article/div[2]/div/div/div/descendant::text()').extract()).strip()
        
        if len(id) < 1: #This is a arbitrary page which does not follow the general form. lazy creator.
            id ="identity field does not exist."
        item['identity'] = id
        
        #personal info.
        pi="".join(response.xpath('/html/body/main/section/div/article/div[2]/div/div/ul[1]/descendant::text()').extract()).strip()
        
        if len(pi)<1:
            pi="personal_info field may not exist. "
        item['personal_info'] = pi
        
        #personal_content
        exp="".join(response.xpath('/html/body/main/section/div/article/div[3]/div/descendant::text()').extract()).strip()
        
        if len(exp)<1:
            exp="personal_content field may not exist."
        item['personal_content'] = exp
        #url
        urlss=response.request.url
        if len(urlss)<1 or "." not in urlss:
            urlss="NULL"
        item['url']=urlss
        
      
        yield item
        
        