import scrapy
from sixth.items import SixthItem
from datetime import datetime
import re


class Sixth(scrapy.Spider):
    name = "sios7"
    #dont_filter=True
    # First Start Url
    
    start_urls = [
    "https://medicine.missouri.edu/faculty", #seems ok
    ]
    for i in range(1,82):
        start_urls.append("https://medicine.missouri.edu/faculty?page=81")
    def parse(self, response):
        for i in range(1, 11):
            
            href = "".join(response.xpath('//*[@id="block-som-content"]/div/div[2]/div/div/div[1]/article/div/div[2]/h2/a/@href').extract())
            if len(href) < 1:
                break
            url=href
            callback=self.parse_dir_contents
            yield scrapy.Request(url, callback)
                        
    
    def parse_dir_contents(self, response):
        item = SixthItem()
        
        #medicine.missouri.edu
        #name
        na = "".join(response.xpath('//*[@id="block-som-content"]/div[1]/div/h1/span/descendant::text()').extract()).strip()
        
        if len(na)<1:
            na = "Name field may not exist."
        item['name'] = na
        
        #personal info.
        pi="".join(response.xpath('//*[@id="block-som-content"]/div[1]/div/div[2]/div[2]/div/descendant::text()').extract()).strip()
        
        if len(pi)<1:
            pi="personal_info field may not exist. "
        item['personal_info'] = pi
        
        #personal content
        exp="".join(response.xpath('//*[@id="block-som-content"]/div[2]/descendant::text()').extract()).strip()
        
        if len(exp)<1:
            exp="education field may not exist. "
        item['personal_content'] = exp
        
        
        #url
        urlss=response.request.url
        if len(urlss)<1 or "." not in urlss:
            urlss="NULL"
        item['url']=urlss
        
        if "medicine.missouri.edu" in urlss:
            na2="".join(response.xpath('//*[@id="block-som-content"]/div[1]/div/h1/span/descendant::text()').extract()).strip()
            pi2="".join(response.xpath('//*[@id="block-som-content"]/div[1]/div/div[2]/div[2]/div/descendant::text()').extract()).strip()
            exp2="".join(response.xpath('//*[@id="block-som-content"]/div[2]/descendant::text()').extract()).strip()
            if len(na2)<1:
            exp="na2 field may not exist. "
            if len(pi2)<1:
            exp="pi2 field may not exist. "
            if len(exp2)<1:
            exp="exp2 field may not exist. "
            item['name']=na2
            item['personal_info']=pi2
            item['personal_content']=exp2
            
        if "www.muhealth.org" in urlss:
        #name
        na1 = "".join(response.xpath('//*[@id="block-doctorbannerblock"]/div/div/div[2]/div/h1/descendant::text()').extract()).strip()
        
        if len(na1)<1:
            na = "Name field may not exist."
        item['name'] = na
        
        #personal info.
        pi1="".join(response.xpath('//*[@id="block-doctorbannerblock"]/div/div/div[3]/div[3]/div/div/a/descendant::text()').extract()).strip()
        
        if len(pi1)<1:
            pi="personal_info field may not exist. "
        item['personal_info'] = pi
        
        #personal content
        exp1="".join(response.xpath('///*[@id="block-muhc-content"]/div/article/descendant::text()').extract()).strip()
        
        if len(exp1)<1:
            exp="education field may not exist. "
        item['personal_content'] = exp   
      
        yield item
        
        