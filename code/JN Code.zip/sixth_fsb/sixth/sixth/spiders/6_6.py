import scrapy
from sixth.items import SixthItem
from datetime import datetime
import re


class Sixth(scrapy.Spider):
    name = "sios6"
    #dont_filter=True
    # First Start Url
    
    start_urls = [
    "http://nep.missouri.edu/faculty.html",#gj
    #"https://medicine.missouri.edu/faculty",#seems ok
    ]
    
    def parse(self, response):
        for i in range(1, 19):
            for o in range(1,3):
                href = "".join(response.xpath('//*[@id="mainContent"]/div['+str(i)+']/div['+str(o)+']/div/p/a/@href').extract())
                if len(href) < 1:
                    break
                url=href
                callback=self.parse_dir_contents
                yield scrapy.Request(url, callback)
                        
    
    def parse_dir_contents(self, response):
        item = SixthItem()
        
        
        #name
        na = "".join(response.xpath('//*[@id="mainContent"]/h3/descendant::text()').extract()).strip()
        
        if len(na)<1:
            na = "Name field may not exist."
        item['name'] = na
        
        #personal info.
        pi="".join(response.xpath('//*[@id="mainContent"]/div[2]/div[2]/p/descendant::text()').extract()).strip()
        
        if len(pi)<1:
            pi="personal_info field may not exist. "
        item['personal_info'] = pi
        
        #personal content
        exp="".join(response.xpath('//*[@id="mainContent"]/h4/descendant::text()').extract()).strip()
        
        if len(exp)<1:
            exp="education field may not exist. "
        item['personal_content'] = exp
        
        
        #url
        urlss=response.request.url
        if len(urlss)<1 or "." not in urlss:
            urlss="NULL"
        item['url']=urlss
        
      
        yield item
        
        