import scrapy
from sixth.items import SixthItem
from datetime import datetime
import re


class Sixth(scrapy.Spider):
    name = "sios1"
    #dont_filter=True
    # First Start Url
    start_urls = [
    "https://biochem.missouri.edu/faculty/",
    #"http://biomed.missouri.edu/faculty-and-staff/",
    #"https://chemistry.missouri.edu/faculty/"
    ]
    
    
    def parse(self, response):
        for i in range(1, 200):
            href = "".join(response.xpath('//*[@id="skip"]/div[2]/div['+str(i)+']/div[1]/h4/a/@href').extract())
            if "missouri" not in href:
                href = response.urljoin(href)
            if len(href) < 1:
                break
            url=href
            callback=self.parse_dir_contents
            if "php" not in url:
                continue
            yield scrapy.Request(url, callback)
                    
    
    def parse_dir_contents(self, response):
        item = SixthItem()#3rd
        
        #name
        na = "".join(response.xpath('//*[@id="skip"]/h2/descendant::text()').extract()).strip()
        
        if len(na)<1:
            na = "Name field may not exist."
        item['name'] = na
        
        #identity. 'if' sequence here is vital
        id = "".join(response.xpath('//*[@id="skip"]/h3[1]').extract())
       
        if len(id) < 1:
            id ="Warning: id may not exist!"
        
        id = id.replace('<br>','\n')
        id = re.sub('<[^<]+?>', ' ', id)
        id= ' '.join(id.split())
        
        item['identity'] = id
        
        #personal info.
        pi="".join(response.xpath('//*[@id="skip"]/div[2]/div').extract())
        
        if len(pi)<1:
            pi="Warning: personal_info may not exist."
        
        pi = pi.replace('</p>','\n')
        pi = re.sub('<[^<]+?>', ' ', pi)
        pi= ' '.join(pi.split())
        item['personal_info'] = pi
        
        #education
        ed = "".join(response.xpath('//*[@id="skip"]/table').extract())
        
        if len(ed) < 1:
            ed = "Warning: Education field does not exist."
            
        ed = ed.replace('</tr>','\n')
        ed = re.sub('<[^<]+?>', ' ', ed)
        ed= ' '.join(ed.split())
        item['education'] = ed
        
        #research description
        res = "".join(response.xpath('//*[@id="skip"]/h3[contains(text(),"Research description")]/following-sibling::p').extract())
        
        if len(res) < 1:
            res = "Warning: research field may not exist."
        res = res.replace('</p>','\n')
        res = re.sub('<[^<]+?>', ' ', res)
        res=' '.join(res.split())
        
        item['research'] = res
        
        #url
        urlss=response.request.url
        if len(urlss)<1 or "." not in urlss:
            urlss="NULL"
        item['url']=urlss
          
        yield item
        
        