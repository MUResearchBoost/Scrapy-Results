import scrapy
from sixth.items import SixthItem
from datetime import datetime
import re


class Sixth(scrapy.Spider):
    name = "sios0"
    #dont_filter=True
    # First Start Url
    start_urls = [
    "http://asm.missouri.edu/faculty/",
    "http://bioengineering.missouri.edu/faculty/",
    "http://foodscience.missouri.edu/faculty/",
    "http://dass.missouri.edu/faculty/",
    "http://fsb.missouri.edu/faculty/",
    "http://gwi.missouri.edu/faculty/",
    "http://hospitality.missouri.edu/faculty/"
    ]#2nd change
    
        
    global count
    count=[]
    count.append(0)
    global lines
    lines=[2,4,6]
    def parse(self, response):
        for i in range(1, 20):#1st change
            check = 0
            end = 0 #check if this page ends
            count_o=0
            for o in range (1, 50):
                count_o+=1
                if check == 1:
                    break
                for s in lines:
                    count[0]+=1
                    href = "".join(response.xpath('//*[@id="primaryContent"]/table['+str(i)+']//tr['+str(o)+']/td['+str(s)+']/a/@href').extract())
                    if "missouri" not in href:
                        href = response.urljoin(href)
                        
                    elif len(href) < 1:
                        check=1
                        if count_o==1:
                            end=1
                        break
            
                    url=href
                    #print(count)#finally, count ==1029
                    callback=self.parse_dir_contents
                    bc=0
            
                    if "php" in url:
                        yield scrapy.Request(url, callback)
                    elif "personnel" in url:
                        yield scrapy.Request(url, callback)
                    elif "cafnr" in url:
                        yield scrapy.Request(url, callback)
                    else:
                        break
            if end == 1:
                break    
    
    def parse_dir_contents(self, response):
        item = SixthItem()#3rd
        sb=0
        
        #name
        na = "".join(response.xpath('//*[@id="primaryContent"]/h2[1]/descendant::text()').extract()).strip()
        if len(na) < 1:# for all special cases, there is only name will be scraped. Check the pages for the rest info.
            na = "".join(response.xpath('//div[@class="person-info"]/h2/descendant::text()').extract()).strip()
            sb=1
        if len(na)<1:
            na = "Name field may not exist."
        item['name'] = na
        
        #identity. if sequence here is vital
        id = "".join(response.xpath('//*[@id="primaryContent"]/b').extract()).strip()
        if len(id) < 1:
            id = "".join(response.xpath('//*[@id="primaryContent"]/strong/descendant::text()').extract()).strip()
        if len(id) < 1:
            id = "".join(response.xpath('//*[@id="primaryContent"]/p/descendant::text()').extract()).strip()
            #three different site for one staff!!
        if len(id) < 1: #This is a arbitrary page which does not follow the general form. lazy creator.
            id ="Warning: No /p /strong /b."
        id = re.sub('<[^<]+?>', ' ', id)
        id= ' '.join(id.split())
        if sb==1:
            id = "This is an unique page. You may check the page directly."
        if len(id)>300:
            id = "".join(response.xpath('//*[@id="primaryContent"]/h3/descendant::text()').extract()).strip()
        item['identity'] = id
        
        #personal info.
        pi="".join(response.xpath('//*[@id="primaryContent"]/ul[@class="text-90"]/descendant::text()').extract()).strip()
        if sb==1:
            pi = "This is an unique page. You may check the page directly."
        if len(pi)<1:
            pi="This field may not exist. Check with the url."
        item['personal_info'] = pi
        
        #education
        ed = "".join(response.xpath('//*[@id="primaryContent"]/h2[2]/following-sibling::ul[count(preceding-sibling::h2) < 3]').extract()).strip()
        ed = re.sub('<[^<]+?>', '\n', ed)
        ed = re.sub(' ', '', ed)
        ed = re.sub('\n', ' ', ed)
        if sb==1:
            ed = "This is an unique page. You may check the page directly."
        if len(ed) < 1:
            ed = "Education field does not exist. Or check the page!"
        item['education'] = ed
        
        #research
        res = "".join(response.xpath('//*[@id="primaryContent"]/h2[3]/following-sibling::ul[count(preceding-sibling::h2) < 4]').extract()).strip()
        if len(res) < 1:
            res = "".join(response.xpath('//*[@id="primaryContent"]/h2[3]/following-sibling::p[count(preceding-sibling::h2) < 4]').extract()).strip()
        if len(res) < 1:
            res = "This field does not exist. Or check the page!"
        res = re.sub('<[^<]+?>', ' ', res)
        res=' '.join(res.split())
        if sb==1:
            res = "This is an unique page. You may check the page directly."
        item['research'] = res
        
        #url
        urlss=response.request.url
        if len(urlss)<1 or "." not in urlss:
            urlss="NULL"
        item['url']=urlss
        
        #modify
        
        if "cafnr" in urlss:
            item['name']="".join(response.xpath('//h1[@itemprop="headline"]/descendant::text()').extract()).strip()
            item['identity']="".join(response.xpath('//h2[@class="person-title"]/descendant::text()').extract()).strip()
            item['personal_info']="".join(response.xpath('//table[@class="contact-info"]/descendant::text()').extract()).strip()
            item['research']="".join(response.xpath('//section[@class="entry-content cf"]/descendant::text()').extract()).strip()
            item['education'] = "This field does not exist."
      
        yield item
        
        