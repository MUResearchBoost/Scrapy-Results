import scrapy
from sixth.items import SixthItem
from datetime import datetime
import re

#failed. it would be done by hand.
class Sixth(scrapy.Spider):
    name = "sios2"
    #dont_filter=True
    # First Start Url
    start_urls = [
    "http://biomed.missouri.edu/faculty-and-staff/",#Shit web. damn frame structure! The creator must be noob!!!
    #"https://chemistry.missouri.edu/faculty/"
    ]
    
    
    def parse(self, response):
        for i in range(1, 200):
            href = "".join(response.xpath('//*[@id="gallery-2"]/dl['+str(i)+']/dt/a/@href').extract())
            if "missouri" not in href:
                href = response.urljoin(href)
            if len(href) < 1:
                break
            url=href
            callback=self.parse_dir_contents
            
            yield scrapy.Request(url, callback)
                    
    
    def parse_dir_contents(self, response):
        item = SixthItem()#3rd
        
        #name
        na = "".join(response.xpath('//*[@id="content"]/div[2]/h1/descendant::text()').extract()).strip()
        
        if len(na)<1:
            na = "Name field may not exist."
        item['name'] = na
        
        #personal info.
        pi="".join(response.xpath('//*[@id="content"]/div[2]/div').extract())
        
        if len(pi)<1:
            pi="Warning: personal_info may not exist."
        
        pi = pi.replace('</p>','\n')
        pi = re.sub('<[^<]div+?>?</div>', '  \zombie\  ', pi)
        pi= ' '.join(pi.split())
        item['personal_info'] = pi
        
        #research interests
        res = "".join(response.xpath('//*[@id="content"]/div[2]/div').extract())
        
        if len(res) < 1:
            res = "Warning: research field may not exist."
        res = res.replace('</p>','\n')
        
        "".join(re.findall("<[^<]div+?>(.*?)</div>", pi,re.DOTALL))
         "".join(re.findall("<[^d]>(.*)</div>", pi,re.DOTALL))
        
        res = re.sub('<[^<]+?>', ' ', res)
        res=' '.join(res.split())
        
        item['research'] = res
        
        #url
        urlss=response.request.url
        if len(urlss)<1 or "." not in urlss:
            urlss="NULL"
        item['url']=urlss
          
        yield item
        
        