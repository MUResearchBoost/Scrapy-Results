# -*- coding: utf-8 -*-

# Define here the models for your scraped items
#
# See documentation in:
# https://doc.scrapy.org/en/latest/topics/items.html

import scrapy


class SixthItem(scrapy.Item):
    # define the fields for your item here like:
    # name = scrapy.Field()
    '''
    name = scrapy.Field()
    research= scrapy.Field()
    url = scrapy.Field()
    #personal_info may cover education and identity, cuz they are all mixed in one part of the pages
    personal_info = scrapy.Field()#contact info
    education = scrapy.Field()
    identity= scrapy.Field()
    '''
    #6 items for 6_0, 6_1,6_4
    #6_2,6_3 are done by hand
    '''
    name = scrapy.Field()
    research= scrapy.Field()
    url = scrapy.Field()
    #personal_info may cover education and identity
    personal_info = scrapy.Field()#contact info
    personal_content=scrapy.Field()#personal_info
    '''
    #^|6_5
    
    
    '''
    name = scrapy.Field()
    url = scrapy.Field()
    #personal_info may cover identity, cuz they all are mixed in one part of the pages
    personal_info = scrapy.Field()
    personal_content=scrapy.Field()#education+search
    '''
    #^|6_6
    
    name = scrapy.Field()
    url = scrapy.Field()
    #personal_info may cover identity, cuz all mixed in one part of the pages
    personal_info = scrapy.Field()#contact+id
    personal_content=scrapy.Field()#all rest
    #^|6_7
    