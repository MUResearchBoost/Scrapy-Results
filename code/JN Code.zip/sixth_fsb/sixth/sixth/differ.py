with open("copied.txt") as file1:
    datac= file1.readlines()
datac=[a.strip() for a in datac]

with open("scraped.txt") as file2:
    datas= file2.readlines()
datas=[b.strip() for b in datas]
miss=[]
count=0
data=[]
for s in datas:
    
    count+=1
    for c in datac:
        if s in c:
            data.append(c)
m=[]
count2=0            
for c in datac:
    check=0
    count2+=1
    for i in data:
        if i == c:
            check = 1
    if check == 0:
        m.append(c)

    
with open('missed_name.txt', 'w') as file:
    for i in m:
        file.write("%s\n" %i)
    file.write("s %d\n c %d\n" %(count,count2))