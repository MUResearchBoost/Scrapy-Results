#this py file collect links from google search.
#output like //en.wikipedia.org/wiki/Computer_science
#output is "list" 


from bs4 import BeautifulSoup
import requests
page = requests.get("https://www.google.dz/search?q=computer science")
soup = BeautifulSoup(page.content, 'lxml')
links = soup.find_all("a")

count = 0
temp=[]
for link in links:
    if 'wikipedia' in link["href"]:
        #print(link["href"])
        temp.append(link["href"])
    count+=1
    #if count >108:
        #print(type(link["href"]))#str
#print(type(links))#<class 'bs4.element.ResultSet'>
print(count)

#deal with it
a=':'
b='&'
list=[]
cop=0
for i in temp:
    list.append(i[i.find(a)+1:i.find(b)])
    cop+=1
print(cop)
print(list)
print("\n"+list[0])