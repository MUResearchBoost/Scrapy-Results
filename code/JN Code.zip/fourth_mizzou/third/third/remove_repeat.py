with open("wiki_urls_0.6.txt") as file:
    data= file.readlines()
data=[e.strip() for e in data]
fill=[]
for s in data:
    a=s.replace(" ", "_")
    fill.append(a)
    
result = []
for item in fill:
    if item not in result:
        result.append(item)
        
with open('wiki_urls_0.7.txt', 'w') as file:
    for i in result:
        file.write("%s\n" %i)