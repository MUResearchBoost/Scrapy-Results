import scrapy
from third.items import ThirdItem
from datetime import datetime
import re
#2018/9/28

class Third(scrapy.Spider):
    name = "my_scraper"
    # First Start Url
    start_urls = ["https://en.wikipedia.org/"]
    
    #read file and clean the format. Then save data as list.
    global data
    data=[]
    with open("wiki_urls_0.7.txt") as file:
        temp= file.readlines()
    data=[e.strip() for e in temp]
    print(data)
    print(type(data))
    def parse(self, response):
        for i in data:
            
            url= "https://en.wikipedia.org"+i
            yield scrapy.Request(url, callback=self.parse_dir_contents)
                
    
    def parse_dir_contents(self, response):
        item = ThirdItem()
        
        # name of the page title. name is always available.^_^
        term = "".join(response.xpath('//*[@id="firstHeading"]/text()').extract())
        item['name'] = term
        
        #check if the page belong to Categories: Disambiguation pages
        dis="".join(response.xpath('//*[@id="mw-normal-catlinks"]/ul/li/a/text()').extract())
        if "Disambiguation pages" in dis:
            item['introduction'] = "This belongs to Disambiguation pages. Open it in your browser"
        elif "stub" in dis:
            item['introduction'] = "This page about an IT-related or software-related company or corporation is a stub."
        else:
            #   !!!!!!!!!!!!!!!
            #   introduction start
            #   !!!!!!!!!!!!!!!
                
            # introduction- all paras
            all_paras=[]
            intro = "".join(response.xpath('//*[@id="mw-content-text"]/div/p[1]/descendant::text()').extract()).strip()
            p_count=[2]#para count
            if len(intro) > 30:
                all_paras.append(intro)
            else:
                while len(intro) < 30:
                    #if para is not the actual para, take the real one. Default: at least one para exists.
                    intro = "".join(response.xpath('//*[@id="mw-content-text"]/div/p['+str(p_count[0])+']/descendant::text()').extract()).strip()
                    p_count[0]+=1
                all_paras.append(intro)
                
            p_count[0]-=1
            check=1
            while check == 1:
                # this loop is used to check if the next tag is <p>, here I check the first char after <
                following=(response.xpath('//*[@id="mw-content-text"]/div/p['+str(p_count[0])+']/following-sibling::*')).extract()
                next_tag=following[0][1]
                if next_tag == "u":
                    intro = "".join(response.xpath('//*[@id="mw-content-text"]/div/ul[1]/descendant::text()').extract()).strip()
                    all_paras.append(intro)
                    check=0 #break
                elif next_tag != "p":
                    check=0
                else:
                    p_count[0]+=1
                    intro = "".join(response.xpath('//*[@id="mw-content-text"]/div/p['+str(p_count[0])+']/descendant::text()').extract()).strip()
                    all_paras.append(intro)
            
            item['introduction'] = "".join(all_paras)
                
            #   !!!!!!!!!!!!!!!
            #   introduction end
            #   !!!!!!!!!!!!!!!
        
        # url (The link to the page)
        urls = "".join(response.xpath('/html/head/link[12]/@href').extract())
        if "en.wikipedia.org/wiki" not in urls:
            item['urlofmajors'] = "https://en.wikipedia.org/wiki/"+term.replace(" ", "_")
        else:
            item['urlofmajors'] = urls
        
        yield item
        
        