with open("wiki_urls_0.5.txt") as file:
    data= file.readlines()
data=[e.strip() for e in data]
fill=[]
for s in data:
    a=s.replace(" ", "_")
    fill.append(a)
with open('wiki_urls_0.6.txt', 'w') as file:
    for i in fill:
        file.write("%s\n" %i)