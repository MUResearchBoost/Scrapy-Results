#this py file collect links from wiki search.
#output like //en.wikipedia.org/wiki/Computer_science
#output is "temp" 
#v0.3

from bs4 import BeautifulSoup
import requests
page = requests.get("https://en.wikipedia.org/w/index.php?search=computer pos")
soup = BeautifulSoup(page.content, 'lxml')
links = soup.find_all("a",{"href":True})

count = 0
temp=[]
for link in links:
    print(link["href"])
    temp.append(link["href"])
    count+=1
    #if count >108:
        #print(type(link["href"]))#str

#print(type(links))#<class 'bs4.element.ResultSet'>
print(count)
print(temp[9])
#write to wiki_urls_0.3.txt
with open('wiki_urls_0.3.txt', 'w') as file:
    for i in temp:
        file.write("%s\n" %i)