this time, the program read name for search from a txt file
but i do not do exact search, so there are some empty pages when some names do not follow the format of wiki or these page may not exist

sequence:
transfer_wiki.py
remove_spqces.py
remove_repeat.py
