#this py file collect links from wiki search.
#output may be //en.wikipedia.org/wiki/Computer_science
#output is "list" 
#v0.5
#2018927 v0.6. Output sample:/wiki/3D_reconstruction
from bs4 import BeautifulSoup
import requests

list=[]
trash=[
"/wiki/Help",
"#mw-head",
"#p-search",
"/w/index.php",
"/wiki/Wikipedia"
]
#read what is to search
with open("categories.txt") as file:
        data= file.readlines()
data=[i.strip() for i in data]
   
for i in data:
    #here is some variables 
    page = requests.get("https://en.wikipedia.org/w/index.php?search="+i+"")
    soup = BeautifulSoup(page.content, 'lxml')
    
    #check if this the page already exists
    title = soup.find("h1")
    ac=title.contents[0]
    
    #wiki give auto revision to the title, so when the title exists, the name may differ from input
    #len>0 means this element exists, != means it's not search result pages, so this page must exist.
    if len(ac) > 0 and ac != "Search results":
        list.append("/wiki/"+ac)
        print("\nawesome!\n")
        continue
    
    # if the page does not exist, do search 
    links = soup.find_all("a",{"href":True})
    index = 0
    temp=[]
    
    for link in links:
        temp.append(link["href"])
        print("link[href] is ",link["href"])
        v=0
        for element in trash:
            if element in link["href"]:
                v=1
        if v==1:
            index+=1
            continue
        break
        

    print(index)
    print(i,"'s url: ",temp[index])# this one should be the first result for any wiki searches
    list.append(temp[index])# save all links to list in the form like //en.wikipedia.org/wiki/Computer_science

    
#write to wiki_urls_0.5.txt
with open('wiki_urls_0.5.txt', 'w') as file:
    for i in list:
        file.write("%s\n" %i)